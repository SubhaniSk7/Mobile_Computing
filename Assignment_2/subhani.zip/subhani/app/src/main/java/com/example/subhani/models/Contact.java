package com.example.subhani.models;

import android.net.Uri;

public class Contact {
    public String name;
    public Uri profilePic;
}
