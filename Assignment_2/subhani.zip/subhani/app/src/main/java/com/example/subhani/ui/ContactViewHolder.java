package com.example.subhani.ui;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.subhani.R;
import com.example.subhani.models.Contact;
import com.squareup.picasso.Picasso;

public class ContactViewHolder extends RecyclerView.ViewHolder {
    private ImageView mProfileImage;
    private TextView mLabel;
    private Contact mBoundContact;

    public ContactViewHolder(final View itemView) {
        super(itemView);
        mProfileImage = (ImageView) itemView.findViewById(R.id.profile_image);
        mLabel = (TextView) itemView.findViewById(R.id.tv_label);
        itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(mBoundContact != null) {
                    Toast.makeText(itemView.getContext(), "Hi, I am "+mBoundContact.name, Toast.LENGTH_LONG).show();
                }
            }
        });
    }
    public void bind(Contact contact){
        mBoundContact = contact;
        mLabel.setText(contact.name);
        Picasso.with(itemView.getContext())
                .load(contact.profilePic)
                .placeholder(R.drawable.ic_launcher_background)
                .error(R.drawable.ic_launcher_background)
                .into(mProfileImage);
    }
}
